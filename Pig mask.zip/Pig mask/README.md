#Pigmask from mother 3
#Ever wanted to play as a poorly made Pigmask from Mother 3? Well here you go chump.